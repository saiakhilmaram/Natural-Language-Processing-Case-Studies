# import packages
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import spacy

def solution():
    #Read the file as a pandas data-frame.
    df = pd.read_csv("res/Eopinions.csv")
    df.head()
    ##Perform Label Encoding on ‘class’ column.
    labelencoder = LabelEncoder()
    df['class'] = labelencoder.fit_transform(df['class'])
    df.head()

    def clean_text(df):
        nlp = spacy.load('en_core_web_sm')
        for i in range(df.shape[0]):
            doc = nlp(df['text'][i])
            text = [w.lemma_.lower().strip() for w in doc
                   if not (w.is_stop | w.is_punct | w.is_digit)]
        text = " ".join(text)
        df['text'][i] = text

        return df
    
    from sklearn.feature_extraction.text import CountVectorizer

    cv = CountVectorizer()

    X = cv.fit_transform(clean_df['text'])
    y = clean_df['class']

    # Split the data into train and test

    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state= 42)

    # Naive Bayes
    from sklearn.naive_bayes import BernoulliNB
    nb = BernoulliNB()
    nb.fit(X_train,y_train)

    y_pred = nb.predict(X_test)
    y_pred

    from sklearn.metrics import classification_report, confusion_matrix
    print("NB Classification report: \n" ,classification_report(y_test,y_pred))

    from sklearn.metrics import  accuracy_score, f1_score, precision_score, recall_score

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    results = pd.DataFrame([['Naive Bayes Classifier', acc,prec,rec, f1],
                        ],
               columns = ['Model', 'Accuracy', 'Precision', 'Recall', 'F1 Score'])
    print(results)



