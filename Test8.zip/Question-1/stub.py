# import packages


def solution():
    #Read the file as a pandas data-frame.
    
    ##Perform Label Encoding on ‘class’ column.
    
    
    #Vectorize the text using CountVectorizer
    
    #Split the dataset into 2 parts namely “train.csv” and “test.csv” having 80% and 20% of the data
    
    #Train your machine learning algorithm for classification and prepare a model
    
    #Now test the model on the Test data and evaluate the Performance by providing Confusion Matrix for your model. 
    